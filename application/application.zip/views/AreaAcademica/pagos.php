<div class="content-wrapper">
	<section class="content">
		<div class="row mb15">
			<div id="box-cursoPeriodo"></div>
			<div class="col-sm-3">
				<button class="btn btn-block btn-success" type="button" id="guardar">Guardar</button>
			</div>
		</div>
		<form id="form">
			<input type="hidden" name="sesiones" value="" />
			<input type="hidden" name="grup_id" value="" />
			<table class="table table-bordered table-hover">
				<thead>
					<tr>
						<th>N°</th>
						<th>Apellidos</th>
						<th>Nombres</th>
						<th>Rango</th>
						<th>Pagos</th>
					</tr>
				</thead>
				<tbody id="table-body">
					
				</tbody>
			</table>
		</form>
	</section>
</div>